import 'dart:io';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:async';
import 'package:http/io_client.dart';
import 'package:stock_api/model/search_model.dart';
import 'package:stock_api/utils/api_key.dart';

class SearchScreen extends StatefulWidget {
  SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  StreamController<List<StockData>?> searchDataController =
      StreamController<List<StockData>?>();
  Timer? _debounce;
  String searchText = '';

  @override
  void dispose() {
    searchDataController.close();
    _debounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home screen")),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Card(
                color: const Color.fromARGB(255, 231, 231, 231),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Center(
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Search for stocks',
                        suffixIcon: Icon(Icons.search),
                      ),
                      onChanged: (value) {
                        if (_debounce != null) {
                          _debounce!.cancel();
                        }
                        _debounce = Timer(
                          const Duration(milliseconds: 500),
                          () {
                            searchDataController.add([]);
                            fetchSearchResults(value);
                            searchText = value;
                          },
                        );
                      },
                    ),
                  ),
                ),
              ),
              StreamBuilder<List<StockData>?>(
                stream: searchDataController.stream,
                builder: (context, snapshot) {
                  if (searchText.isEmpty) {
                    return Text("Search for companies");
                  } else if (snapshot.connectionState ==
                      ConnectionState.waiting) {
                    return Center(child: Text("Loading..."));
                  } else if (snapshot.hasData && snapshot.data != null) {
                    final searchData = snapshot.data!;
                    return SizedBox(
                      height: MediaQuery.of(context).size.height -
                          kBottomNavigationBarHeight,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Card(
                          color: const Color.fromARGB(255, 231, 231, 231),
                          child: ListView.separated(
                            separatorBuilder: (context, index) => Divider(),
                            itemCount: searchData.length,
                            itemBuilder: (context, index) {
                              final company = searchData[index];
                              return ListTile(
                                title: Text(company.name),
                                subtitle: FutureBuilder<String>(
                                  future: fetchCompanyData(company.symbol),
                                  builder: (context, snapshot) {
                                    if (snapshot.connectionState ==
                                        ConnectionState.waiting) {
                                      return Text(
                                        "Loading....",
                                        style: TextStyle(fontSize: 14),
                                      );
                                    } else {
                                      final data = snapshot.data;
                                      if (data != null && data.isNotEmpty) {
                                        return Text(data);
                                      } else {
                                        return Text('No data found');
                                      }
                                    }
                                  },
                                ),
                                trailing: GestureDetector(
                                  child:
                                      Icon(Icons.add_circle_outline_outlined),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    );
                  } else {
                    return Center(child: Text("No data found"));
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<String> fetchCompanyData(String companyName) async {
    const globalFunction = 'GLOBAL_QUOTE';

    try {
      final ioc = HttpClient();
      ioc.badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
      final http = IOClient(ioc);
      final apiUrl =
          'https://www.alphavantage.co/query?function=$globalFunction&symbol=$companyName&apikey=$apiKey';
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['Global Quote'] != null) {
          final globalQuoteData = data['Global Quote']['05. price'];
          return '$globalQuoteData';
        } else {
          return 'No data available';
        }
      } else {
        print(
            "Failed to fetch company data. Status code: ${response.statusCode}");
        return 'Error fetching company data';
      }
    } catch (e) {
      print("Error fetching company data: $e");
      return 'Error fetching company data';
    }
  }

  Future<void> fetchSearchResults(String keyword) async {
    const function = 'SYMBOL_SEARCH';
    try {
      final ioc = HttpClient();
      ioc.badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
      final http = IOClient(ioc);
      final apiUrl =
          'https://www.alphavantage.co/query?function=$function&keywords=$keyword&apikey=$apiKey';

      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['bestMatches'] != null) {
          final matches = List<Map<String, dynamic>>.from(data['bestMatches']);
          final stockData =
              matches.map((match) => StockData.fromJson(match)).toList();
          searchDataController.add(stockData);
        } else {
          searchDataController.add([]);
        }
      } else {
        print("Failed to fetch data. Status code: ${response.statusCode}");
        searchDataController.addError(
            "Failed to fetch data. Status code: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching data: $e");
      searchDataController.addError("Error fetching data: $e");
    }
  }
}

